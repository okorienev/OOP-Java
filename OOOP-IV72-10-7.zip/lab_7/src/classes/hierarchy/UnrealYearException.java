package classes.hierarchy;

public class UnrealYearException extends IllegalArgumentException {
    public UnrealYearException() {
    }

    public UnrealYearException(String s) {
        super(s);
    }
}
